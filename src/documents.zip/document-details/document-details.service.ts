import { Injectable } from '@nestjs/common';
import { CreateDocumentDetailInput } from './dto/create-document-detail.input';
import { UpdateDocumentDetailInput } from './dto/update-document-detail.input';

@Injectable()
export class DocumentDetailsService {
  create(createDocumentDetailInput: CreateDocumentDetailInput) {
    return 'This action adds a new documentDetail';
  }

  findAll() {
    return `This action returns all documentDetails`;
  }

  findOne(id: number) {
    return `This action returns a #${id} documentDetail`;
  }

  update(id: number, updateDocumentDetailInput: UpdateDocumentDetailInput) {
    return `This action updates a #${id} documentDetail`;
  }

  remove(id: number) {
    return `This action removes a #${id} documentDetail`;
  }
}
