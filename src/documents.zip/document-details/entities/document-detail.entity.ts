import { ObjectType, Field, Float, Int } from '@nestjs/graphql';

@ObjectType()
export class DocumentDetail {
  @Field(() => Int)
  SOPTYPE              : number;
  @Field()
  SOPNUMBE             : string;
  @Field(() => Int)
  LNITMSEQ             : number;
  @Field(() => Int)
  CMPNTSEQ             : number;
  @Field()
  ITEMNMBR             : string;
  @Field()
  ITEMDESC             : string;
  @Field(() => Int)
  NONINVEN             : number;
  @Field(() => Int)
  DROPSHIP             : number;
  @Field()
  UOFM                 : string;
  @Field()
  LOCNCODE             : string;
  @Field(() => Float)
  UNITCOST: number;
  @Field(() => Float)
  ORUNTCST: number;
  @Field(() => Float)
  UNITPRCE: number;
  @Field(() => Float)
  ORUNTPRC: number;
  @Field(() => Float)
  XTNDPRCE: number;
  @Field(() => Float)
  OXTNDPRC: number;
  @Field(() => Float)
  REMPRICE: number;
  @Field(() => Float)
  OREPRICE: number;
  @Field(() => Float)
  EXTDCOST: number;
  @Field(() => Float)
  OREXTCST: number;
  @Field(() => Float)
  MRKDNAMT: number;
  @Field(() => Float)
  ORMRKDAM: number;
  @Field(() => Int)
  MRKDNPCT             : number;
  @Field(() => Int)
  MRKDNTYP             : number;
  @Field(() => Int)
  INVINDX              : number;
  @Field(() => Int)
  CSLSINDX             : number;
  @Field(() => Int)
  SLSINDX              : number;
  @Field(() => Int)
  MKDNINDX             : number;
  @Field(() => Int)
  RTNSINDX             : number;
  @Field(() => Int)
  INUSINDX             : number;
  @Field(() => Int)
  INSRINDX             : number;
  @Field(() => Int)
  DMGDINDX             : number;
  @Field()
  ITMTSHID             : string;
  @Field(() => Int)
  IVITMTXB             : number;
  @Field(() => Float)
  BKTSLSAM             : number;
  @Field(() => Float)
  ORBKTSLS             : number;
  @Field(() => Float)
  TAXAMNT              : number;
  @Field(() => Float)
  ORTAXAMT             : number;
  @Field(() => Float)
  TXBTXAMT             : number;
  @Field(() => Float)
  OTAXTAMT             : number;
  @Field(() => Int)
  BSIVCTTL             : number;      
  @Field(() => Float)
  TRDISAMT             : number;
  @Field(() => Float)
  ORTDISAM             : number;
  @Field(() => Float)
  DISCSALE             : number;
  @Field(() => Float)
  ORDAVSLS             : number;
  @Field(() => Float)
  QUANTITY             : number;
  @Field(() => Float)
  ATYALLOC             : number;
  @Field(() => Float)
  QTYINSVC             : number;
  @Field(() => Float)
  QTYINUSE             : number;
  @Field(() => Float)
  QTYDMGED             : number;
  @Field(() => Float)
  QTYRTRND             : number;
  @Field(() => Float)
  QTYONHND             : number;
  @Field(() => Float)
  QTYCANCE             : number;
  @Field(() => Float)
  QTYCANOT             : number;
  @Field(() => Float)
  QTYONPO              : number;
  @Field(() => Float)
  QTYORDER             : number;
  @Field(() => Float)
  QTYPRBAC             : number;
  @Field(() => Float)
  QTYPRBOO             : number;
  @Field(() => Float)
  QTYPRINV             : number;
  @Field(() => Float)
  QTYPRORD             : number;
  @Field(() => Float)
  QTYPRVRECVD          : number;
  @Field(() => Float)
  QTYRECVD             : number;
  @Field(() => Float)
  QTYREMAI             : number;
  @Field(() => Float)
  QTYREMBO             : number;
  @Field(() => Float)
  QTYTBAOR             : number;
  @Field(() => Float)
  QTYTOINV             : number;
  @Field(() => Float)
  QTYTORDR             : number;
  @Field(() => Float)
  QTYFULFI             : number;
  @Field(() => Float)
  QTYSLCTD             : number;
  @Field(() => Float)
  QTYBSUOM             : number;
  @Field(() => Float)
  EXTQTYAL             : number;
  @Field(() => Float)
  EXTQTYSEL            : number;
  @Field()
  ReqShipDate          : Date;
  @Field()
  FUFILDAT             : Date;
  @Field()
  ACTLSHIP             : Date;
  @Field()
  SHIPMTHD             : string;
  @Field()
  SALSTERR             : string;
  @Field()
  SLPRSNID             : string;
  @Field()
  PRCLEVEL             : string;
  @Field()
  COMMNTID             : string;
  @Field(() => Int)
  BRKFLD1              : number;
  @Field(() => Int)
  BRKFLD2              : number;
  @Field(() => Int)
  BRKFLD3              : number;
  @Field(() => Int)
  CURRNIDX             : number;
  @Field()
  TRXSORCE             : string;
  @Field(() => Int)
  SOPLNERR             : number;
  @Field(() => Int)
  ORGSEQNM             : number;
  @Field()
  ITEMCODE             : string;
  @Field(() => Int)
  PURCHSTAT            : number;
  @Field(() => Int)
  DECPLQTY             : number;
  @Field(() => Int)
  DECPLCUR             : number;
  @Field(() => Int)
  ODECPLCU             : number;
  @Field(() => Float)
  QTYTOSHP             : number;
  @Field(() => Int)
  XFRSHDOC             : number;      
  @Field(() => Int)
  EXCEPTIONALDEMAND    : number;      
  @Field()
  TAXSCHID             : string;
  @Field(() => Int)
  TXSCHSRC             : number;
  @Field()
  PRSTADCD             : string;
  @Field()
  ShipToName           : string;
  @Field()
  CNTCPRSN             : string;
  @Field()
  ADDRESS1             : string;
  @Field()
  ADDRESS2             : string;
  @Field()
  ADDRESS3             : string;
  @Field()
  CITY                 : string;
  @Field()
  STATE                : string;
  @Field()
  ZIPCODE              : string;
  @Field()
  CCode                : string;
  @Field()
  COUNTRY              : string;
  @Field()
  PHONE1               : string;
  @Field()
  PHONE2               : string;
  @Field()
  PHONE3               : string;
  @Field()
  FAXNUMBR             : string;
  @Field(() => Int)
  Flags                : number;
  @Field(() => Float)
  BackoutTradeDisc     : number;
  @Field(() => Float)
  OrigBackoutTradeDisc : number;
  @Field()
  GPSFOINTEGRATIONID   : string;
  @Field(() => Int)
  INTEGRATIONSOURCE    : number;
  @Field()
  INTEGRATIONID        : string;
  @Field()
  CONTNBR              : string;
  @Field(() => Float)
  CONTLNSEQNBR         : number;
  @Field()
  CONTSTARTDTE         : Date;
  @Field()
  CONTENDDTE           : Date;
  @Field()
  CONTITEMNBR          : string;
  @Field()
  CONTSERIALNBR        : string;
  @Field(() => Int)
  BULKPICKPRNT         : number;      
  @Field(() => Int)
  INDPICKPRNT          : number;      
  @Field(() => Int)
  ISLINEINTRA          : number;      
  @Field()
  SOFULFILLMENTBIN     : string;
  @Field(() => Int)
  MULTIPLEBINS         : number;      
  @Field(() => Int)
  Print_Phone_NumberGB : number;
  @Field()
  DEX_ROW_TS: Date;
  @Field(() => Int)
  DEX_ROW_ID           : number;
}
