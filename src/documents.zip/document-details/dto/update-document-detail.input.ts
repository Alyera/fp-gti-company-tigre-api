import { CreateDocumentDetailInput } from './create-document-detail.input';
import { InputType, Field, Int, PartialType } from '@nestjs/graphql';

@InputType()
export class UpdateDocumentDetailInput extends PartialType(CreateDocumentDetailInput) {
  @Field(() => Int)
  id: number;
}
