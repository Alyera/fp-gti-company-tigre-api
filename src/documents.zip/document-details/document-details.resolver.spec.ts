import { Test, TestingModule } from '@nestjs/testing';
import { DocumentDetailsResolver } from './document-details.resolver';
import { DocumentDetailsService } from './document-details.service';

describe('DocumentDetailsResolver', () => {
  let resolver: DocumentDetailsResolver;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [DocumentDetailsResolver, DocumentDetailsService],
    }).compile();

    resolver = module.get<DocumentDetailsResolver>(DocumentDetailsResolver);
  });

  it('should be defined', () => {
    expect(resolver).toBeDefined();
  });
});
