import { Resolver, Query, Mutation, Args, Int } from '@nestjs/graphql';
import { DocumentDetailsService } from './document-details.service';
import { DocumentDetail } from './entities/document-detail.entity';
import { CreateDocumentDetailInput } from './dto/create-document-detail.input';
import { UpdateDocumentDetailInput } from './dto/update-document-detail.input';

@Resolver(() => DocumentDetail)
export class DocumentDetailsResolver {
  constructor(private readonly documentDetailsService: DocumentDetailsService) {}

  @Mutation(() => DocumentDetail)
  createDocumentDetail(@Args('createDocumentDetailInput') createDocumentDetailInput: CreateDocumentDetailInput) {
    return this.documentDetailsService.create(createDocumentDetailInput);
  }

  @Query(() => [DocumentDetail], { name: 'documentDetails' })
  findAll() {
    return this.documentDetailsService.findAll();
  }

  @Query(() => DocumentDetail, { name: 'documentDetail' })
  findOne(@Args('id', { type: () => Int }) id: number) {
    return this.documentDetailsService.findOne(id);
  }

  @Mutation(() => DocumentDetail)
  updateDocumentDetail(@Args('updateDocumentDetailInput') updateDocumentDetailInput: UpdateDocumentDetailInput) {
    return this.documentDetailsService.update(updateDocumentDetailInput.id, updateDocumentDetailInput);
  }

  @Mutation(() => DocumentDetail)
  removeDocumentDetail(@Args('id', { type: () => Int }) id: number) {
    return this.documentDetailsService.remove(id);
  }
}
