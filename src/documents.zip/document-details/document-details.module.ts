import { Module } from '@nestjs/common';
import { DocumentDetailsService } from './document-details.service';
import { DocumentDetailsResolver } from './document-details.resolver';

@Module({
  providers: [DocumentDetailsResolver, DocumentDetailsService],
})
export class DocumentDetailsModule {}
