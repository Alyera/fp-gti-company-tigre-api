import { Module } from '@nestjs/common';
import { DocumentsService } from './documents.service';
import { DocumentsResolver } from './documents.resolver';
import { PrismaService } from 'src/prisma/prisma.service';

@Module({
  providers: [DocumentsResolver, DocumentsService, PrismaService],
})
export class DocumentsModule {}
