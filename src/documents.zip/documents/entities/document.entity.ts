import { ObjectType, Field, Int, Float } from '@nestjs/graphql';
import { Client } from 'src/clients/entities/client.entity';

@ObjectType()
export class Document {
  @Field(() => Int)
  SOPTYPE: number;
  @Field()
  SOPNUMBE: string;
  @Field(() => Int)
  ORIGTYPE: number;
  @Field()
  ORIGNUMB: string;
  @Field()
  DOCID: string;
  @Field()
  DOCDATE: Date;
  @Field()
  GLPOSTDT: Date;
  @Field()
  QUOTEDAT: Date;
  @Field()
  QUOEXPDA: Date;
  @Field()
  ORDRDATE: Date;
  @Field()
  INVODATE: Date;
  @Field()
  BACKDATE: Date;
  @Field()
  RETUDATE: Date;
  @Field()
  ReqShipDate: Date;
  @Field()
  FUFILDAT: Date;
  @Field()
  ACTLSHIP: Date;
  @Field()
  DISCDATE: Date;
  @Field()
  DUEDATE: Date;
  @Field(() => Int)
  REPTING: number;
  @Field(() => Int)
  TRXFREQU: number;
  @Field(() => Int)
  TIMEREPD: number;
  @Field(() => Int)
  TIMETREP: number;
  @Field(() => Int)
  DYSTINCR: number;
  DTLSTREP: Date;
  @Field()
  DSTBTCH1: string;
  @Field()
  DSTBTCH2: string;
  @Field()
  USDOCID1: string;
  @Field()
  USDOCID2: string;
  @Field(() => Float)
  DISCFRGT: number;
  @Field(() => Float)
  ORDAVFRT: number;
  @Field(() => Float)
  DISCMISC: number;
  @Field(() => Float)
  ORDAVMSC: number;
  @Field(() => Float)
  DISAVAMT: number;
  @Field(() => Float)
  ORDAVAMT: number;
  @Field(() => Float)
  DISCRTND: number;
  @Field(() => Float)
  ORDISRTD: number;
  @Field(() => Float)
  DISTKNAM: number;
  @Field(() => Float)
  ORDISTKN: number;
  @Field(() => Int)
  DSCPCTAM: number;
  @Field(() => Float)
  DSCDLRAM: number;
  @Field(() => Float)
  ORDDLRAT: number;
  @Field(() => Float)
  DISAVTKN: number;
  @Field(() => Float)
  ORDATKN: number;
  @Field()
  PYMTRMID: string;
  @Field()
  PRCLEVEL: string;
  @Field()
  LOCNCODE: string;
  @Field()
  BCHSOURC: string;
  @Field()
  BACHNUMB: string;
  @Field()
  CUSTNMBR: string;
  @Field()
  CUSTNAME: string;
  @Field()
  CSTPONBR: string;
  @Field(() => Int)
  PROSPECT: number;
  @Field(() => Int)
  MSTRNUMB: number;
  @Field()
  PCKSLPNO: string;
  @Field()
  PICTICNU: string;
  @Field(() => Float)
  MRKDNAMT: number;
  @Field(() => Float)
  ORMRKDAM: number;
  @Field()
  PRBTADCD: string;
  @Field()
  PRSTADCD: string;
  @Field()
  CNTCPRSN: string;
  @Field()
  ShipToName: string;
  @Field()
  ADDRESS1: string;
  @Field()
  ADDRESS2: string;
  @Field()
  ADDRESS3: string;
  @Field()
  CITY: string;
  @Field()
  STATE: string;
  @Field()
  ZIPCODE: string;
  @Field()
  CCode: string;
  @Field()
  COUNTRY: string;
  @Field()
  PHNUMBR1: string;
  @Field()
  PHNUMBR2: string;
  @Field()
  PHONE3: string;
  @Field()
  FAXNUMBR: string;
  @Field(() => Int)
  COMAPPTO: number;
  @Field(() => Float)
  COMMAMNT: number;
  @Field(() => Float)
  OCOMMAMT: number;
  @Field(() => Float)
  CMMSLAMT: number;
  @Field(() => Float)
  ORCOSAMT: number;
  @Field(() => Float)
  NCOMAMNT: number;
  @Field(() => Float)
  ORNCMAMT: number;
  @Field()
  SHIPMTHD: string;
  @Field(() => Float)
  TRDISAMT: number;
  @Field(() => Float)
  ORTDISAM: number;
  @Field(() => Int)
  TRDISPCT: number;
  @Field(() => Float)
  SUBTOTAL: number;
  @Field(() => Float)
  ORSUBTOT: number;
  @Field(() => Float)
  REMSUBTO: number;
  @Field(() => Float)
  OREMSUBT: number;
  @Field(() => Float)
  EXTDCOST: number;
  @Field(() => Float)
  OREXTCST: number;
  @Field(() => Float)
  FRTAMNT: number;
  @Field(() => Float)
  ORFRTAMT: number;
  @Field(() => Float)
  MISCAMNT: number;
  @Field(() => Float)
  ORMISCAMT: number;
  @Field(() => Int)
  TXENGCLD: number;
  @Field()
  TAXEXMT1: string;
  @Field()
  TAXEXMT2: string;
  @Field()
  TXRGNNUM: string;
  @Field()
  TAXSCHID: string;
  @Field(() => Int)
  TXSCHSRC: number;
  @Field(() => Int)
  BSIVCTTL: number;
  @Field()
  FRTSCHID: string;
  @Field(() => Float)
  FRTTXAMT: number;
  @Field(() => Float)
  ORFRTTAX: number;
  @Field(() => Int)
  FRGTTXBL: number;
  @Field()
  MSCSCHID: string;
  @Field(() => Float)
  MSCTXAMT: number;
  @Field(() => Float)
  ORMSCTAX: number;
  @Field(() => Int)
  MISCTXBL: number;
  @Field(() => Float)
  BKTFRTAM: number;
  @Field(() => Float)
  ORBKTFRT: number;
  @Field(() => Float)
  BKTMSCAM: number;
  @Field(() => Float)
  ORBKTMSC: number;
  @Field(() => Float)
  BCKTXAMT: number;
  @Field(() => Float)
  OBTAXAMT: number;
  @Field(() => Float)
  TXBTXAMT: number;
  @Field(() => Float)
  OTAXTAMT: number;
  @Field(() => Float)
  TAXAMNT: number;
  @Field(() => Float)
  ORTAXAMT: number;
  @Field(() => Int)
  ECTRX: number;
  @Field(() => Float)
  DOCAMNT: number;
  @Field(() => Float)
  ORDOCAMT: number;
  @Field(() => Float)
  PYMTRCVD: number;
  @Field(() => Float)
  ORPMTRVD: number;
  @Field(() => Float)
  DEPRECVD: number;
  @Field(() => Float)
  ORDEPRVD: number;
  @Field(() => Float)
  CODAMNT: number;
  @Field(() => Float)
  ORCODAMT: number;
  @Field(() => Float)
  ACCTAMNT: number;
  @Field(() => Float)
  ORACTAMT: number;
  @Field()
  SALSTERR: string;
  @Field()
  SLPRSNID: string;
  @Field()
  UPSZONE: string;
  @Field(() => Int)
  TIMESPRT: number;
  @Field(() => Int)
  PSTGSTUS: number;
  @Field(() => Int)
  VOIDSTTS: number;
  @Field(() => Int)
  ALLOCABY: number;
  @Field(() => Float)
  NOTEINDX: number;
  @Field()
  CURNCYID: string;
  @Field(() => Int)
  CURRNIDX: number;
  @Field()
  RATETPID: string;
  @Field()
  EXGTBLID: string;
  @Field(() => Float)
  XCHGRATE: number;
  @Field(() => Float)
  DENXRATE: number;
  @Field()
  EXCHDATE: Date;
  @Field()
  TIME1: Date;
  @Field(() => Int)
  RTCLCMTD: number;
  @Field(() => Int)
  MCTRXSTT: number;
  @Field()
  TRXSORCE: string;
  @Field(() => Int)
  SOPHDRE1: number;
  @Field(() => Int)
  SOPHDRE2: number;
  @Field(() => Int)
  SOPLNERR: number;
  @Field(() => Int)
  SOPHDRFL: number;
  @Field(() => Int)
  SOPMCERR: number;
  @Field()
  COMMNTID: string;
  @Field()
  REFRENCE: string;
  @Field()
  POSTEDDT: Date;
  @Field()
  PTDUSRID: string;
  @Field()
  USER2ENT: string;
  @Field()
  CREATDDT: Date;
  @Field()
  MODIFDT: Date;
  @Field()
  Tax_Date: Date;
  @Field(() => Int)
  APLYWITH: number;
  @Field(() => Float)
  WITHHAMT: number;
  @Field(() => Int)
  SHPPGDOC: number;
  @Field(() => Int)
  CORRCTN: number;
  @Field(() => Int)
  SIMPLIFD: number;
  @Field(() => Int)
  CORRNXST: number;
  @Field()
  DOCNCORR: string;
  @Field(() => Int)
  SEQNCORR: number;
  SALEDATE: Date;
  @Field(() => Int)
  SOPHDRE3: number;
  @Field(() => Int)
  EXCEPTIONALDEMAND: number;
  @Field(() => Int)
  Flags: number;
  @Field(() => Float)
  BackoutTradeDisc: number;
  @Field(() => Float)
  OrigBackoutTradeDisc: number;
  @Field()
  GPSFOINTEGRATIONID: string;
  @Field(() => Int)
  INTEGRATIONSOURCE: number;
  @Field()
  INTEGRATIONID: string;
  @Field(() => Int)
  SOPSTATUS: number;
  @Field(() => Int)
  SHIPCOMPLETE: number;
  @Field(() => Int)
  DIRECTDEBIT: number;
  @Field(() => Int)
  WorkflowApprStatCreditLm: number;
  @Field(() => Int)
  WorkflowPriorityCreditLm: number;
  @Field(() => Int)
  WorkflowApprStatusQuote: number;
  @Field(() => Int)
  WorkflowPriorityQuote: number;
  @Field(() => Int)
  Workflow_Status: number;
  @Field(() => Int)
  ContractExchangeRateStat: number;
  @Field(() => Int)
  Print_Phone_NumberGB: number;
  @Field()
  DEX_ROW_TS: Date;
  @Field(() => Int)
  DEX_ROW_ID: number;

  @Field((type) => Client, { nullable: false })
  client: Client;
}
